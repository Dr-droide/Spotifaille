﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Spotifaille
{
    public partial class mainForm : Form
    {
        private FileReadAndWrite playlistPath;

        public mainForm()
        {
            InitializeComponent();
            playlistComboBox.Items.Add("Ajouter une Playlist");
            playlistPath = new FileReadAndWrite();
            playlistListView.Columns.Add("Titre", 150);
            playlistListView.Columns.Add("Artiste", 130);
            playlistListView.Columns.Add("Durée", 130);
            playlistLabel.Text = "Aucune";
            titreLabel.Text = "Aucun";
        }

        private void playlistComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            //De base la comboBox est vide et on peut uniquement cliquer sur "importer une playlist" dans la combo box.
            //si on fait ça, ça ouvre un explorateur de fichiers qui demande de select le fichier playlist.txt
            //une fois la playlist chargée, on mémorise son nom et son filepath, et on l'ajoute dans la liste des playlists
            //Actualise le nom de la playlist en temps réel en fonction de celle qui est sélectionnée. Si aucune, affiche "Aucune"
            //Affiche la playlist dans la listView à droite
            //Affiche la liste des titres contenus dans playlist.txt
            //Si aucune playlist sélectionnée, laisser la liste vide
            //Actualise le nom du titre en temps réel en fonction de celui qui est sélectionné. Si aucun, affiche "Aucun"
            //***PLANTE SI ON FERME LA FENETRE DE SELECTION DE FICHIER SANS SELECTIONNER DE FICHIER****

            String tmpPlaylistLabel = Path.GetFileName(playlistPath.FilePath);

            String selected = playlistComboBox.SelectedItem.ToString();
            if (selected == "Ajouter une Playlist") {
                openFileDialog1.ShowDialog();
            }

            playlistListView.Items.Clear();

            FileReadAndWrite playlist = new FileReadAndWrite();
            List<String> playlistList = playlist.CsvToList(playlistPath.FilePath);

            int i = 0;
            String[] array = new string[3];
            while (i < playlistList.Count)
            {
                array[0] = playlistList[i];
                array[1] = playlistList[i + 1];
                array[2] = playlistList[i + 2];
                playlistListView.Items.Add(new ListViewItem(array));

                if (playlistList.Count + 3 > i)
                {
                    i += 3;                
                }else if (playlistList.Count + 2 > i)
                {
                    i += 2;
                }
                else {
                    i++;
                }
            }

            Boolean ok = true;
            for (i = 0; i < playlistComboBox.Items.Count; i++)
            {
                if (playlistComboBox.Items[i].ToString() == Path.GetFileName(playlistPath.FilePath))
                {
                    ok = false;
                }
            }

            if (ok)
            {
                playlistComboBox.Items.Add(Path.GetFileName(playlistPath.FilePath));
            }

            if(tmpPlaylistLabel == Path.GetFileName(playlistPath.FilePath))
            {
                playlistLabel.Text = selected.Remove(selected.Length-4);
            }
            else
            {
                playlistLabel.Text = Path.GetFileName(playlistPath.FilePath.Remove(playlistPath.FilePath.Length-4));
            }

        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            playlistPath.FilePath = openFileDialog1.FileName;
        }

        private void playlistListView_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (playlistListView.SelectedItems.Count != 0)
            {
                titreLabel.Text = playlistListView.SelectedItems[0].Text;
            }
        }
    }
}
