﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Spotifaille
{
    public class FileReadAndWrite
    {

        /// <summary>
        /// Stocke l'emplacement du fichier de log
        /// </summary>
        private string filePath;

        /// <summary>
        /// Constructeur surchargé qui initialise le champs filePath
        /// à un chemin d'écriture du log par défault,
        /// c'est à dire dans le même dossier que l'application, dans un fichier
        /// qui se nomme log.txt
        /// </summary>
        public FileReadAndWrite()
        {
            this.filePath = "log.txt";
        }

        public string FilePath { get => filePath; set => filePath = value; }

        /// <summary>
        /// Ecriture d'une ligne datée dans le fichier de log
        /// </summary>
        /// <param name="lineToLog">la ligne à logger</param>
        public void Log(string lineToLog)
        {
            try
            {
                if (!File.Exists(filePath))
                {
                    FileStream fileStr = File.Create(filePath);
                }
                //Pass the filepath and filename to the StreamWriter Constructor
                StreamWriter sw = new StreamWriter(filePath, true);
                //Write a line of text
                sw.WriteLine(DateTime.Now + ":" + lineToLog);
                //Close the file
                sw.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                MessageBox.Show(e.Message, "Erreur d'écriture sur le fichier de Log");
            }
        }

        public List<String> CsvToList(string pathToCsvFile)
        {
            List<String> list = new List<String>();
            using (var reader = new StreamReader(pathToCsvFile))
            {
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    if (line == null || line == "") continue;
                    var values = line.Split(',');

                        for (int i = 0; i<3; i++) {
                            list.Add(values[i]);
                        }
                }
            }

            return list;
        }
    }
}